using System;
using System.Drawing;
using System.Linq;
using System.Windows.Forms;

namespace FootballManager
{
    public partial class MainMenuForm : Form
    {
        private string userRole;
        private Panel pnlSidebar;
        private Panel pnlHeader;
        private Panel pnlContent;
        private Label lblHeaderTitle;
        private Form activeChildForm;
        private Button activeSidebarButton;

        public MainMenuForm(string role)
        {
            InitializeComponent();
            this.userRole = role;
            SetupMenuUI();
            Theme.Apply(this);
        }

        #region Setup UI
        private void SetupMenuUI()
        {
            this.Text = $"fManager - Главно меню ({userRole})";
            this.Size = new Size(1240, 750);
            this.StartPosition = FormStartPosition.CenterScreen;
            this.FormBorderStyle = FormBorderStyle.FixedSingle;

            // 1. Sidebar Panel
            pnlSidebar = new Panel()
            {
                Name = "pnlSidebar",
                Dock = DockStyle.Left,
                Width = 240
            };
            
            // 2. Header Panel
            pnlHeader = new Panel()
            {
                Name = "pnlHeader",
                Dock = DockStyle.Top,
                Height = 65
            };
            
            // 3. Content Panel
            pnlContent = new Panel()
            {
                Name = "pnlContent",
                Dock = DockStyle.Fill
            };
            
            // Добавяме контролите към формата. 
            // Редът на добавяне + BringToFront/SendToBack е критичен за правилното Dock поведение в WinForms!
            this.Controls.Add(pnlContent);
            this.Controls.Add(pnlHeader);
            this.Controls.Add(pnlSidebar);

            // Правилно позициониране, за да не се застъпват:
            pnlSidebar.SendToBack(); // Docks FIRST (взема цялата височина вляво)
            pnlHeader.SendToBack();  // Docks SECOND (взема горната част от останалото място)
            pnlContent.BringToFront(); // Docks LAST (запълва останалото)

            // Separator Line in Header
            Panel pnlSeparator = new Panel()
            {
                BackColor = Color.FromArgb(51, 65, 85), // Slate 700
                Dock = DockStyle.Bottom,
                Height = 1
            };
            pnlHeader.Controls.Add(pnlSeparator);

            // Header Title Label
            lblHeaderTitle = new Label()
            {
                Text = "Добре дошли в fManager",
                Font = new Font("Montserrat", 16, FontStyle.Bold),
                ForeColor = Theme.TextColor,
                Location = new Point(25, 18),
                AutoSize = true
            };
            pnlHeader.Controls.Add(lblHeaderTitle);

            // Sidebar Logo/Branding
            Label lblLogo = new Label()
            {
                Text = "fManager",
                Font = new Font("Montserrat", 14, FontStyle.Bold),
                ForeColor = Color.White,
                Location = new Point(25, 20),
                AutoSize = true
            };
            pnlSidebar.Controls.Add(lblLogo);

            // Menu Buttons
            int startY = 80;
            int buttonHeight = 45;
            int spacing = 6;

            CreateMenuButton("Клубове и Отбори", startY, BtnClubs_Click);
            CreateMenuButton("Играчи", startY + (buttonHeight + spacing) * 1, BtnPlayers_Click);
            CreateMenuButton("Трансферен център", startY + (buttonHeight + spacing) * 2, BtnTransfers_Click);
            CreateMenuButton("Първенства (Лиги)", startY + (buttonHeight + spacing) * 3, BtnLeagues_Click);
            CreateMenuButton("Мачове и Резултати", startY + (buttonHeight + spacing) * 4, BtnMatches_Click);
            CreateMenuButton("Класиране на лига", startY + (buttonHeight + spacing) * 5, BtnStandings_Click);
            CreateMenuButton("Топ Голмайстори", startY + (buttonHeight + spacing) * 6, BtnStats_Click);
            
            if (userRole == "Admin")
            {
                CreateMenuButton("Потребители", startY + (buttonHeight + spacing) * 7, BtnUsers_Click);
            }

            // Profile info and logout in a bottom-docked panel to prevent cutoff
            Panel pnlSidebarBottom = new Panel()
            {
                Dock = DockStyle.Bottom,
                Height = 100,
                BackColor = Color.Transparent
            };
            pnlSidebar.Controls.Add(pnlSidebarBottom);

            Label lblUserRole = new Label()
            {
                Text = $"Роля: {userRole}",
                Font = new Font("Montserrat", 10, FontStyle.Regular),
                ForeColor = Color.FromArgb(156, 163, 175),
                Location = new Point(25, 15),
                AutoSize = true
            };
            pnlSidebarBottom.Controls.Add(lblUserRole);

            Button btnLogout = new Button()
            {
                Text = "Изход от системата",
                Location = new Point(20, 45),
                Size = new Size(200, 40),
                Font = new Font("Montserrat", 10, FontStyle.Bold),
                BackColor = Theme.DangerColor,
                ForeColor = Color.White,
                FlatStyle = FlatStyle.Flat,
                Cursor = Cursors.Hand
            };
            btnLogout.FlatAppearance.BorderSize = 0;
            btnLogout.Click += BtnLogout_Click;
            pnlSidebarBottom.Controls.Add(btnLogout);

            // Load default view (Standings table) on startup
            Button btnDefault = pnlSidebar.Controls.OfType<Button>().FirstOrDefault(b => b.Text.Contains("Класиране"));
            ShowFormInContentPanel(new StandingsForm(), btnDefault);
        }

        private void CreateMenuButton(string text, int y, EventHandler onClick)
        {
            Button btn = new Button()
            {
                Text = text,
                Location = new Point(0, y),
                Size = new Size(240, 45),
                FlatStyle = FlatStyle.Flat,
                Cursor = Cursors.Hand
            };
            btn.FlatAppearance.BorderSize = 0;
            btn.Click += onClick;
            pnlSidebar.Controls.Add(btn);
        }

        private void ShowFormInContentPanel(Form childForm, Button sidebarButton)
        {
            if (activeChildForm != null)
            {
                activeChildForm.Close();
                activeChildForm.Dispose();
            }

            activeChildForm = childForm;
            lblHeaderTitle.Text = childForm.Text;

            // Highlight active button in sidebar
            if (activeSidebarButton != null)
            {
                activeSidebarButton.Tag = null;
                activeSidebarButton.BackColor = Theme.SidebarColor;
                activeSidebarButton.ForeColor = Color.FromArgb(156, 163, 175);
            }

            if (sidebarButton != null)
            {
                activeSidebarButton = sidebarButton;
                sidebarButton.Tag = "Active";
                sidebarButton.BackColor = Theme.SidebarActiveColor;
                sidebarButton.ForeColor = Color.White;
            }

            // Embed child form — fill the entire content area to prevent cutoff
            childForm.TopLevel = false;
            childForm.FormBorderStyle = FormBorderStyle.None;
            childForm.Dock = DockStyle.Fill;
            childForm.AutoScroll = true;
            
            pnlContent.Controls.Clear();
            pnlContent.Controls.Add(childForm);
            childForm.Show();
        }
        #endregion

        #region Event Handlers
        private void BtnClubs_Click(object sender, EventArgs e) 
        { 
            ShowFormInContentPanel(new ClubsForm(), (Button)sender); 
        }

        private void BtnPlayers_Click(object sender, EventArgs e) 
        { 
            ShowFormInContentPanel(new PlayersForm(), (Button)sender); 
        }

        private void BtnTransfers_Click(object sender, EventArgs e) 
        { 
            ShowFormInContentPanel(new TransfersForm(), (Button)sender); 
        }

        private void BtnLeagues_Click(object sender, EventArgs e) 
        { 
            ShowFormInContentPanel(new LeaguesForm(), (Button)sender); 
        }

        private void BtnMatches_Click(object sender, EventArgs e) 
        { 
            ShowFormInContentPanel(new MatchesForm(), (Button)sender); 
        }

        private void BtnStandings_Click(object sender, EventArgs e) 
        { 
            ShowFormInContentPanel(new StandingsForm(), (Button)sender); 
        }

        private void BtnStats_Click(object sender, EventArgs e) 
        { 
            ShowFormInContentPanel(new StatsForm(), (Button)sender); 
        }

        private void BtnUsers_Click(object sender, EventArgs e)
        {
            ShowFormInContentPanel(new UsersForm(), (Button)sender);
        }

        private void BtnLogout_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form1 loginForm = new Form1();
            loginForm.Show();
        }

        protected override void OnFormClosed(FormClosedEventArgs e)
        {
            base.OnFormClosed(e);
            Environment.Exit(0);
        }
        #endregion
    }
}
