using System;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Windows.Forms;

namespace FootballManager
{
    public partial class UsersForm : Form
    {
        private DataGridView gridUsers;
        private TextBox txtUsername;
        private TextBox txtPassword;
        private ComboBox cmbRole;
        private Button btnSave, btnDelete, btnClear;
        private int selectedUserId = 0;

        public UsersForm()
        {
            this.Text = "Управление на потребители";
            this.Size = new Size(950, 650);
            this.BackColor = Theme.BackgroundColor;

            int y = 70;

            // Header
            Label lblTitle = new Label() { Text = "Управление на потребители", Location = new Point(20, 15), AutoSize = true };
            lblTitle.Font = new Font("Montserrat", 14, FontStyle.Bold);
            this.Controls.Add(lblTitle);

            // Inputs
            this.Controls.Add(new Label() { Text = "Потребителско име:", Location = new Point(20, y), AutoSize = true, ForeColor = Theme.TextColor, Font = new Font("Montserrat", 10) });
            txtUsername = new TextBox() { Location = new Point(20, y + 30), Width = 180 };
            this.Controls.Add(txtUsername);

            this.Controls.Add(new Label() { Text = "Парола (остави празно за запазване):", Location = new Point(220, y), AutoSize = true, ForeColor = Theme.TextColor, Font = new Font("Montserrat", 10) });
            txtPassword = new TextBox() { Location = new Point(220, y + 30), Width = 180, PasswordChar = '*' };
            this.Controls.Add(txtPassword);

            this.Controls.Add(new Label() { Text = "Роля:", Location = new Point(420, y), AutoSize = true, ForeColor = Theme.TextColor, Font = new Font("Montserrat", 10) });
            cmbRole = new ComboBox() { Location = new Point(420, y + 30), Width = 150, DropDownStyle = ComboBoxStyle.DropDownList };
            cmbRole.Items.AddRange(new string[] { "Admin", "User", "Scout" });
            cmbRole.SelectedIndex = 1;
            this.Controls.Add(cmbRole);

            // Buttons
            int btnY = y + 75;
            btnSave = new Button() { Text = "Запази", Location = new Point(20, btnY) };
            btnDelete = new Button() { Text = "Изтрий", Location = new Point(160, btnY), Enabled = false, BackColor = Theme.DangerColor, ForeColor = Color.White };
            btnClear = new Button() { Text = "Изчисти", Location = new Point(300, btnY) };

            btnSave.Click += BtnSave_Click;
            btnDelete.Click += BtnDelete_Click;
            btnClear.Click += BtnClear_Click;

            this.Controls.Add(btnSave);
            this.Controls.Add(btnDelete);
            this.Controls.Add(btnClear);

            // Grid
            gridUsers = new DataGridView()
            {
                Location = new Point(20, btnY + 50),
                Size = new Size(900, 400),
                ReadOnly = true
            };
            gridUsers.CellClick += GridUsers_CellClick;
            this.Controls.Add(gridUsers);

            Theme.Apply(this);
            LoadUsers();
        }

        private void LoadUsers()
        {
            try
            {
                using (SqlConnection conn = Db.GetConnection())
                {
                    SqlDataAdapter da = new SqlDataAdapter("SELECT UserId, Username, Role FROM Users", conn);
                    DataTable dt = new DataTable();
                    da.Fill(dt);
                    gridUsers.DataSource = dt;
                    gridUsers.Columns["UserId"].HeaderText = "ID";
                    gridUsers.Columns["Username"].HeaderText = "Потребителско име";
                    gridUsers.Columns["Role"].HeaderText = "Роля";
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Грешка при зареждане: " + ex.Message);
            }
        }

        private void BtnSave_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtUsername.Text))
            {
                MessageBox.Show("Моля въведете потребителско име!");
                return;
            }

            try
            {
                using (SqlConnection conn = Db.GetConnection())
                {
                    string query;
                    SqlCommand cmd = new SqlCommand();
                    cmd.Connection = conn;

                    if (selectedUserId == 0)
                    {
                        // Insert
                        if (string.IsNullOrWhiteSpace(txtPassword.Text))
                        {
                            MessageBox.Show("Моля въведете парола за новия потребител!");
                            return;
                        }

                        query = "INSERT INTO Users (Username, PasswordHash, Role) VALUES (@u, @p, @r)";
                        cmd.Parameters.AddWithValue("@u", txtUsername.Text);
                        cmd.Parameters.AddWithValue("@p", txtPassword.Text);
                        cmd.Parameters.AddWithValue("@r", cmbRole.SelectedItem.ToString());
                    }
                    else
                    {
                        // Update
                        if (string.IsNullOrWhiteSpace(txtPassword.Text))
                        {
                            query = "UPDATE Users SET Username=@u, Role=@r WHERE UserId=@id";
                        }
                        else
                        {
                            query = "UPDATE Users SET Username=@u, PasswordHash=@p, Role=@r WHERE UserId=@id";
                            cmd.Parameters.AddWithValue("@p", txtPassword.Text);
                        }
                        cmd.Parameters.AddWithValue("@u", txtUsername.Text);
                        cmd.Parameters.AddWithValue("@r", cmbRole.SelectedItem.ToString());
                        cmd.Parameters.AddWithValue("@id", selectedUserId);
                    }

                    cmd.CommandText = query;
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Успешен запис!");
                    ClearForm();
                    LoadUsers();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Грешка при запазване: " + ex.Message);
            }
        }

        private void GridUsers_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                DataGridViewRow row = gridUsers.Rows[e.RowIndex];
                selectedUserId = Convert.ToInt32(row.Cells["UserId"].Value);
                txtUsername.Text = row.Cells["Username"].Value.ToString();
                cmbRole.SelectedItem = row.Cells["Role"].Value.ToString();
                txtPassword.Text = ""; // За сигурност не показваме паролата
                btnDelete.Enabled = true;
            }
        }

        private void BtnDelete_Click(object sender, EventArgs e)
        {
            if (selectedUserId > 0)
            {
                if (MessageBox.Show("Сигурни ли сте, че искате да изтриете този потребител?", "Изтриване", MessageBoxButtons.YesNo) == DialogResult.Yes)
                {
                    try
                    {
                        using (SqlConnection conn = Db.GetConnection())
                        {
                            SqlCommand cmd = new SqlCommand("DELETE FROM Users WHERE UserId=@id", conn);
                            cmd.Parameters.AddWithValue("@id", selectedUserId);
                            cmd.ExecuteNonQuery();
                            MessageBox.Show("Потребителят е изтрит!");
                            ClearForm();
                            LoadUsers();
                        }
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Грешка при изтриване: " + ex.Message);
                    }
                }
            }
        }

        private void BtnClear_Click(object sender, EventArgs e)
        {
            ClearForm();
        }

        private void ClearForm()
        {
            selectedUserId = 0;
            txtUsername.Clear();
            txtPassword.Clear();
            cmbRole.SelectedIndex = 1;
            btnDelete.Enabled = false;
        }
    }
}
