using System;
using System.Drawing;
using System.Windows.Forms;

namespace FootballManager
{
    public static class Theme
    {
        // ── PREMIUM DARK PALETTE ──────────────────────────────────────
        public static Color BackgroundColor = Color.FromArgb(15, 23, 42);      // Slate 900
        public static Color PanelColor      = Color.FromArgb(30, 41, 59);      // Slate 800
        public static Color CardColor       = Color.FromArgb(30, 41, 59);      // Slate 800 (cards)
        public static Color SurfaceColor    = Color.FromArgb(51, 65, 85);      // Slate 700 (inputs, borders)
        public static Color TextColor       = Color.FromArgb(241, 245, 249);   // Slate 100
        public static Color MutedTextColor  = Color.FromArgb(148, 163, 184);   // Slate 400

        // Accent Colors
        public static Color PrimaryColor    = Color.FromArgb(99, 102, 241);    // Indigo 500
        public static Color SecondaryColor  = Color.FromArgb(16, 185, 129);    // Emerald 500
        public static Color DangerColor     = Color.FromArgb(239, 68, 68);     // Red 500
        public static Color WarningColor    = Color.FromArgb(245, 158, 11);    // Amber 500
        public static Color ButtonTextColor = Color.White;

        // Sidebar
        public static Color SidebarColor        = Color.FromArgb(2, 6, 23);    // Slate 950
        public static Color SidebarButtonHover   = Color.FromArgb(30, 41, 59); // Slate 800
        public static Color SidebarActiveColor   = Color.FromArgb(79, 70, 229);// Indigo 600

        // Grid alternating rows
        public static Color GridRowAlt      = Color.FromArgb(22, 33, 52);      // slightly lighter than BG
        public static Color GridBorder      = Color.FromArgb(51, 65, 85);      // Slate 700

        // ── APPLY TO FORM ─────────────────────────────────────────────
        public static void Apply(Form form)
        {
            form.BackColor = BackgroundColor;
            form.ForeColor = TextColor;

            if (form.FormBorderStyle != FormBorderStyle.None)
            {
                form.FormBorderStyle = FormBorderStyle.FixedSingle;
                form.MaximizeBox = false;
            }

            foreach (Control c in form.Controls)
                ApplyToControl(c);
        }

        // ── RECURSIVE CONTROL STYLING ─────────────────────────────────
        private static void ApplyToControl(Control c)
        {
            // ── PANELS ──
            if (c is Panel pnl)
            {
                if (pnl.Name == "pnlSidebar")
                    pnl.BackColor = SidebarColor;
                else if (pnl.Name == "pnlHeader")
                    pnl.BackColor = PanelColor;
                else if (pnl.Name == "pnlCard")
                    pnl.BackColor = CardColor;
                else
                    pnl.BackColor = BackgroundColor;
            }

            // ── BUTTONS ──
            else if (c is Button btn)
            {
                bool isSidebar = btn.Parent != null &&
                    (btn.Parent.Name == "pnlSidebar" ||
                     btn.Parent.Parent?.Name == "pnlSidebar" ||
                     btn.Parent.Name == "pnlSidebarBottom");

                if (isSidebar)
                {
                    StyleSidebarButton(btn);
                }
                else
                {
                    StyleActionButton(btn);
                }
            }

            // ── LABELS ──
            else if (c is Label lbl)
            {
                bool inSidebar = lbl.Parent != null &&
                    (lbl.Parent.Name == "pnlSidebar" || lbl.Parent.Name == "pnlSidebarBottom");

                if (inSidebar)
                {
                    lbl.ForeColor = Color.White;
                }
                else
                {
                    lbl.ForeColor = TextColor;
                }

                // Upgrade small labels to Montserrat
                if (lbl.Font.FontFamily.Name != "Montserrat" || lbl.Font.Size < 9.5f)
                {
                    if (lbl.Font.Size >= 12)
                        lbl.Font = new Font("Montserrat", lbl.Font.Size, lbl.Font.Style);
                    else
                        lbl.Font = new Font("Montserrat", 10f, lbl.Font.Style);
                }
            }

            // ── DATAGRIDVIEW ──
            else if (c is DataGridView grid)
            {
                StyleDataGrid(grid);
            }

            // ── TEXT INPUTS ──
            else if (c is TextBox txt)
            {
                txt.BackColor = SurfaceColor;
                txt.ForeColor = TextColor;
                txt.Font = new Font("Montserrat", 10.5f);
                txt.BorderStyle = BorderStyle.FixedSingle;
            }
            else if (c is ComboBox combo)
            {
                combo.BackColor = SurfaceColor;
                combo.ForeColor = TextColor;
                combo.Font = new Font("Montserrat", 10.5f);
                combo.FlatStyle = FlatStyle.Flat;
            }
            else if (c is ListBox list)
            {
                list.BackColor = SurfaceColor;
                list.ForeColor = TextColor;
                list.Font = new Font("Montserrat", 10.5f);
                list.BorderStyle = BorderStyle.FixedSingle;
            }
            else if (c is NumericUpDown num)
            {
                num.BackColor = SurfaceColor;
                num.ForeColor = TextColor;
                num.Font = new Font("Montserrat", 10.5f);
                num.BorderStyle = BorderStyle.FixedSingle;
            }
            else if (c is DateTimePicker dtp)
            {
                dtp.Font = new Font("Montserrat", 10.5f);
            }
            else if (c is CheckBox chk)
            {
                chk.ForeColor = TextColor;
                chk.Font = new Font("Montserrat", 10f);
            }

            // Recurse into child controls
            if (c.HasChildren)
            {
                foreach (Control child in c.Controls)
                    ApplyToControl(child);
            }
        }

        // ── SIDEBAR BUTTON ────────────────────────────────────────────
        private static void StyleSidebarButton(Button btn)
        {
            btn.FlatStyle = FlatStyle.Flat;
            btn.FlatAppearance.BorderSize = 0;
            btn.Cursor = Cursors.Hand;
            btn.Font = new Font("Montserrat", 10.5f, FontStyle.Bold);
            btn.TextAlign = ContentAlignment.MiddleLeft;
            btn.Padding = new Padding(25, 0, 0, 0);

            if (btn.Tag != null && btn.Tag.ToString() == "Active")
            {
                btn.BackColor = SidebarActiveColor;
                btn.ForeColor = Color.White;
            }
            else
            {
                btn.BackColor = SidebarColor;
                btn.ForeColor = MutedTextColor;
            }

            btn.FlatAppearance.MouseOverBackColor = SidebarButtonHover;
            btn.FlatAppearance.MouseDownBackColor = SidebarActiveColor;
        }

        // ── ACTION BUTTON ─────────────────────────────────────────────
        private static void StyleActionButton(Button btn)
        {
            btn.FlatStyle = FlatStyle.Flat;
            btn.FlatAppearance.BorderSize = 0;
            btn.Cursor = Cursors.Hand;
            btn.Font = new Font("Montserrat", 9.5f, FontStyle.Bold);
            btn.ForeColor = ButtonTextColor;

            // Fixed size to prevent overlap — generous enough for Cyrillic
            btn.AutoSize = false;
            btn.Height = 38;
            if (btn.Width < 130) btn.Width = 130;

            string text = btn.Text.ToUpper();

            if (text.Contains("ИЗТРИЙ") || text.Contains("МАХНИ") || text == "X" || text.Contains("ЗАТВОРИ") || text.Contains("ОТКАЖИ"))
                btn.BackColor = DangerColor;
            else if (text.Contains("ЗАПИШИ") || text.Contains("СЪЗДАЙ") || text.Contains("ДОБАВИ") || text.Contains("ГОЛ") || text.Contains("ПОДПИШИ") || text.Contains("ВХОД") || text.Contains("ЗАПАЗИ"))
                btn.BackColor = SecondaryColor;
            else if (text.Contains("ПРОМЕНИ"))
            {
                btn.BackColor = WarningColor;
                btn.ForeColor = Color.White;
            }
            else if (text.Contains("ГЕНЕРИРАЙ"))
            {
                btn.BackColor = PrimaryColor;
                btn.Width = 220;
            }
            else
                btn.BackColor = PrimaryColor;

            btn.FlatAppearance.MouseOverBackColor = Brighten(btn.BackColor, 25);
            btn.FlatAppearance.MouseDownBackColor = Darken(btn.BackColor, 30);
        }

        // ── DATAGRIDVIEW PREMIUM STYLING ──────────────────────────────
        private static void StyleDataGrid(DataGridView grid)
        {
            grid.BackgroundColor = BackgroundColor;
            grid.BorderStyle = BorderStyle.None;
            grid.EnableHeadersVisualStyles = false;

            // Double buffering for smooth scrolling
            try
            {
                var prop = typeof(Control).GetProperty("DoubleBuffered",
                    System.Reflection.BindingFlags.NonPublic | System.Reflection.BindingFlags.Instance);
                prop?.SetValue(grid, true, null);
            }
            catch { }

            // Column headers
            grid.ColumnHeadersDefaultCellStyle.BackColor = Color.FromArgb(30, 41, 59); // Slate 800
            grid.ColumnHeadersDefaultCellStyle.ForeColor = MutedTextColor;
            grid.ColumnHeadersDefaultCellStyle.Font = new Font("Montserrat", 9f, FontStyle.Bold);
            grid.ColumnHeadersDefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleLeft;
            grid.ColumnHeadersDefaultCellStyle.Padding = new Padding(8, 0, 0, 0);
            grid.ColumnHeadersHeight = 42;
            grid.ColumnHeadersBorderStyle = DataGridViewHeaderBorderStyle.None;

            // Row styling
            grid.DefaultCellStyle.BackColor = BackgroundColor;
            grid.DefaultCellStyle.ForeColor = TextColor;
            grid.DefaultCellStyle.Font = new Font("Montserrat", 9.5f);
            grid.DefaultCellStyle.Padding = new Padding(8, 4, 4, 4);

            // Alternating rows for visual distinction
            grid.AlternatingRowsDefaultCellStyle.BackColor = GridRowAlt;
            grid.AlternatingRowsDefaultCellStyle.ForeColor = TextColor;

            // Selection highlight
            grid.DefaultCellStyle.SelectionBackColor = Color.FromArgb(67, 56, 202);  // Indigo 700
            grid.DefaultCellStyle.SelectionForeColor = Color.White;

            grid.RowTemplate.Height = 38;
            grid.CellBorderStyle = DataGridViewCellBorderStyle.SingleHorizontal;
            grid.GridColor = Color.FromArgb(30, 41, 59); // subtle dividers
            grid.RowHeadersVisible = false;

            // Auto size columns for better content fit
            grid.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
        }

        // ── COLOR UTILITIES ───────────────────────────────────────────
        private static Color Brighten(Color color, int amount)
        {
            return Color.FromArgb(
                Math.Min(255, color.R + amount),
                Math.Min(255, color.G + amount),
                Math.Min(255, color.B + amount));
        }

        private static Color Darken(Color color, int amount)
        {
            return Color.FromArgb(
                Math.Max(0, color.R - amount),
                Math.Max(0, color.G - amount),
                Math.Max(0, color.B - amount));
        }
    }
}
