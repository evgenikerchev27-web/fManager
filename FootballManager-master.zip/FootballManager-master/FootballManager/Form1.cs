using System;
using System.Data.SqlClient;
using System.Drawing;
using System.Windows.Forms;

namespace FootballManager
{
    public partial class Form1 : Form
    {
        private TextBox txtUsername;
        private TextBox txtPassword;
        private Button btnLogin;
        private Label lblStatus;

        public Form1()
        {
            InitializeComponent();
            SetupTestUI();
            Theme.Apply(this);
        }

        #region Setup UI
        private void SetupTestUI()
        {
            this.Text = "fManager - Вход";
            this.Size = new Size(450, 420);
            this.StartPosition = FormStartPosition.CenterScreen;

            // Създаваме централна "карта"
            Panel pnlCard = new Panel()
            {
                Name = "pnlCard",
                Size = new Size(370, 320),
                Location = new Point(32, 25),
                BorderStyle = BorderStyle.None
            };

            Label lblTitle = new Label() 
            { 
                Text = "fManager", 
                Location = new Point(30, 20), 
                Font = new Font("Montserrat", 16, FontStyle.Bold), 
                ForeColor = Theme.PrimaryColor,
                AutoSize = true 
            };

            Label lblSubtitle = new Label()
            {
                Text = "Моля, въведете данните си за вход",
                Location = new Point(30, 52),
                Font = new Font("Montserrat", 9, FontStyle.Regular),
                ForeColor = Color.Gray,
                AutoSize = true
            };

            Label lblUser = new Label() 
            { 
                Text = "Потребителско име", 
                Location = new Point(30, 90), 
                Font = new Font("Montserrat", 9.5f, FontStyle.Bold),
                AutoSize = true 
            };
            
            txtUsername = new TextBox() 
            { 
                Location = new Point(30, 120), 
                Width = 310
            };

            Label lblPass = new Label() 
            { 
                Text = "Парола", 
                Location = new Point(30, 160), 
                Font = new Font("Montserrat", 9.5f, FontStyle.Bold),
                AutoSize = true 
            };
            
            txtPassword = new TextBox() 
            { 
                Location = new Point(30, 190), 
                Width = 310, 
                PasswordChar = '*' 
            };

            btnLogin = new Button() 
            { 
                Text = "ВХОД", 
                Location = new Point(30, 240), 
                Width = 310, 
                Height = 40
            };
            btnLogin.Click += BtnLogin_Click;

            lblStatus = new Label() 
            { 
                Text = "", 
                Location = new Point(30, 290), 
                AutoSize = true, 
                ForeColor = Color.Red 
            };

            // Добавяме елементите към картата
            pnlCard.Controls.Add(lblTitle);
            pnlCard.Controls.Add(lblSubtitle);
            pnlCard.Controls.Add(lblUser); 
            pnlCard.Controls.Add(txtUsername);
            pnlCard.Controls.Add(lblPass); 
            pnlCard.Controls.Add(txtPassword);
            pnlCard.Controls.Add(btnLogin); 
            pnlCard.Controls.Add(lblStatus);

            // Добавяме картата към формата
            this.Controls.Add(pnlCard);
        }
        #endregion

        #region Event Handlers & Database Logic
        private void BtnLogin_Click(object sender, EventArgs e)
        {
            string username = txtUsername.Text;
            string password = txtPassword.Text;

            if (string.IsNullOrWhiteSpace(username) || string.IsNullOrWhiteSpace(password))
            {
                MessageBox.Show("Моля въведете име и парола!", "Грешка");
                return;
            }

            try
            {
                using (SqlConnection conn = Db.GetConnection())
                {
                    string query = "SELECT Role FROM Users WHERE Username = @u AND PasswordHash = @p";
                    SqlCommand cmd = new SqlCommand(query, conn);
                    cmd.Parameters.AddWithValue("@u", username);
                    cmd.Parameters.AddWithValue("@p", password);

                    object result = cmd.ExecuteScalar();

                    if (result != null)
                    {
                        string role = result.ToString();
                        lblStatus.ForeColor = Color.Green;
                        lblStatus.Text = $"Успех! Роля: {role}";
                        MessageBox.Show($"Добре дошъл, {username}!\nТи си: {role}", "Успешен вход");

                        this.Hide();
                        MainMenuForm menu = new MainMenuForm(role);
                        menu.Show();
                    }
                    else
                    {
                        lblStatus.ForeColor = Color.Red;
                        lblStatus.Text = "Грешно име или парола.";
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Грешка с базата данни: " + ex.Message, "System Error");
            }
        }
        #endregion
    }
}
